"""Initial exercise to check that the Python environment can be used
from the interpreter and the command line.

Created on 2 Apr 2015

@author: paulross
"""

def main():
    print 'Hi there'

if __name__ == '__main__':
    main()
